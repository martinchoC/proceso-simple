      <footer class="app-footer">
        <!--begin::To the end-->
        <div class="float-end d-none d-sm-inline">Anything you want</div>
        <!--end::To the end-->
        <!--begin::Copyright-->
        <strong>
          Copyright &copy; <?php echo "2017-".date("Y");?>
          <a href="https://developsam.com" class="text-decoration-none">Developsam</a>.
        </strong>
        All rights reserved.
        <!--end::Copyright-->
      </footer>
      