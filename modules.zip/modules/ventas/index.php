<?php
require_once __DIR__ . '/../../core/plantilla.php';
$contenido = __FILE__; // Para que layout.php sepa qué mostrar
include TEMPLATE_PATH . '/layout.php';
?>

<div class="card">
  <div class="card-body">
    <h3>Módulo de Ventas</h3>
    <p>Contenido funcional aquí...</p>
  </div>
</div>
