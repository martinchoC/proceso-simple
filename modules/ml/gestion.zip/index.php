<?php

$pageTitle = "Gestión de Multiempresa";
$modudo_idx = 2;
// Definir constante para rutas
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));

// Incluir header
require_once ROOT_PATH . '/templates/adminlte/header1.php';









require_once ROOT_PATH . '/templates/adminlte/footer1.php';



?>