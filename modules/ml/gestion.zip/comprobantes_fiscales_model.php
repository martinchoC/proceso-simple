<?php
require_once "conexion.php";

function obtenerComprobantesFiscales($conexion) {
    $sql = "SELECT * FROM `gestion__comprobantes_fiscales` 
            ORDER BY codigo";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function agregarComprobanteFiscal($conexion, $data) {
    if (empty($data['comprobante_fiscal']) || empty($data['codigo'])) {
        return false;
    }
    
    $comprobante_fiscal = mysqli_real_escape_string($conexion, $data['comprobante_fiscal']);
    $codigo = intval($data['codigo']);
    $estado_registro_id = intval($data['estado_registro_id']);

    // Verificar si ya existe el código
    $sql_check = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_fiscales` 
                  WHERE codigo = $codigo";
    $res_check = mysqli_query($conexion, $sql_check);
    $existe_codigo = mysqli_fetch_assoc($res_check)['existe'];
    
    if ($existe_codigo > 0) {
        return false; // Ya existe este código
    }

    // Verificar si ya existe el nombre
    $sql_check_nombre = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_fiscales` 
                         WHERE comprobante_fiscal = '$comprobante_fiscal'";
    $res_check_nombre = mysqli_query($conexion, $sql_check_nombre);
    $existe_nombre = mysqli_fetch_assoc($res_check_nombre)['existe'];
    
    if ($existe_nombre > 0) {
        return false; // Ya existe este nombre
    }

    $sql = "INSERT INTO `gestion__comprobantes_fiscales` 
            (codigo, comprobante_fiscal, estado_registro_id) 
            VALUES 
            ($codigo, '$comprobante_fiscal', $estado_registro_id)";
    
    return mysqli_query($conexion, $sql);
}

function editarComprobanteFiscal($conexion, $id, $data) {
    if (empty($data['comprobante_fiscal']) || empty($data['codigo'])) {
        return false;
    }
    
    $id = intval($id);
    $comprobante_fiscal = mysqli_real_escape_string($conexion, $data['comprobante_fiscal']);
    $codigo = intval($data['codigo']);
    $estado_registro_id = intval($data['estado_registro_id']);

    // Verificar si ya existe el código (excluyendo el registro actual)
    $sql_check_codigo = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_fiscales` 
                         WHERE codigo = $codigo 
                         AND comprobante_fiscal_id != $id";
    $res_check_codigo = mysqli_query($conexion, $sql_check_codigo);
    $existe_codigo = mysqli_fetch_assoc($res_check_codigo)['existe'];
    
    if ($existe_codigo > 0) {
        return false; // Ya existe este código
    }

    // Verificar si ya existe el nombre (excluyendo el registro actual)
    $sql_check_nombre = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_fiscales` 
                         WHERE comprobante_fiscal = '$comprobante_fiscal'
                         AND comprobante_fiscal_id != $id";
    $res_check_nombre = mysqli_query($conexion, $sql_check_nombre);
    $existe_nombre = mysqli_fetch_assoc($res_check_nombre)['existe'];
    
    if ($existe_nombre > 0) {
        return false; // Ya existe este nombre
    }

    $sql = "UPDATE `gestion__comprobantes_fiscales` SET
            codigo = $codigo,
            comprobante_fiscal = '$comprobante_fiscal',
            estado_registro_id = $estado_registro_id
            WHERE comprobante_fiscal_id = $id";

    return mysqli_query($conexion, $sql);
}

function cambiarEstadoComprobanteFiscal($conexion, $id, $nuevo_estado) {
    $id = intval($id);
    $nuevo_estado = intval($nuevo_estado);
    
    // Mapear los estados: 1=Activo, 2=Inactivo → 1=Activo, 0=Inactivo
    $estado_bd = ($nuevo_estado == 1) ? 1 : 0;
    
    $sql = "UPDATE `gestion__comprobantes_fiscales` 
            SET estado_registro_id = $estado_bd 
            WHERE comprobante_fiscal_id = $id";
    return mysqli_query($conexion, $sql);
}

function eliminarComprobanteFiscal($conexion, $id) {
    $id = intval($id);
    
    // Verificar si está siendo usado en otras tablas (aquí puedes agregar las verificaciones necesarias)
    // Por ejemplo, si hay tipos de comprobantes que usan este fiscal
    
    $sql = "DELETE FROM `gestion__comprobantes_fiscales` 
            WHERE comprobante_fiscal_id = $id";
    return mysqli_query($conexion, $sql);
}

function obtenerComprobanteFiscalPorId($conexion, $id) {
    $id = intval($id);
    $sql = "SELECT * FROM `gestion__comprobantes_fiscales` 
            WHERE comprobante_fiscal_id = $id";
    $res = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($res);
}
?>