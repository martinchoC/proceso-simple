<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once "comprobantes_fiscales_model.php";

$accion = $_REQUEST['accion'] ?? '';

header('Content-Type: application/json; charset=utf-8');

switch ($accion) {
    case 'listar':
        $comprobantes_fiscales = obtenerComprobantesFiscales($conexion);
        echo json_encode($comprobantes_fiscales);
        break;
    
    case 'agregar':
        $data = [
            'codigo' => $_POST['codigo'] ?? 0,
            'comprobante_fiscal' => $_POST['comprobante_fiscal'] ?? '',
            'estado_registro_id' => $_POST['estado_registro_id'] ?? 1
        ];
        
        if (empty($data['comprobante_fiscal']) || $data['codigo'] <= 0) {
            echo json_encode(['resultado' => false, 'error' => 'Código y nombre son obligatorios']);
            break;
        }
        
        $resultado = agregarComprobanteFiscal($conexion, $data);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'Ya existe un comprobante fiscal con ese código o nombre']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'editar':
        $id = intval($_POST['comprobante_fiscal_id']);
        $data = [
            'codigo' => $_POST['codigo'] ?? 0,
            'comprobante_fiscal' => $_POST['comprobante_fiscal'] ?? '',
            'estado_registro_id' => $_POST['estado_registro_id'] ?? 1
        ];
        
        if (empty($data['comprobante_fiscal']) || $data['codigo'] <= 0) {
            echo json_encode(['resultado' => false, 'error' => 'Código y nombre son obligatorios']);
            break;
        }
        
        $resultado = editarComprobanteFiscal($conexion, $id, $data);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'Ya existe un comprobante fiscal con ese código o nombre']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'cambiar_estado':
        $id = intval($_GET['comprobante_fiscal_id']);
        $nuevo_estado = intval($_GET['nuevo_estado']);
        $resultado = cambiarEstadoComprobanteFiscal($conexion, $id, $nuevo_estado);
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'eliminar':
        $id = intval($_GET['comprobante_fiscal_id']);
        $resultado = eliminarComprobanteFiscal($conexion, $id);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'No se puede eliminar el comprobante fiscal porque está siendo usado']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'obtener':
        $id = intval($_GET['comprobante_fiscal_id']);
        $comprobante_fiscal = obtenerComprobanteFiscalPorId($conexion, $id);
        echo json_encode($comprobante_fiscal);
        break;

    default:
        echo json_encode(['error' => 'Acción no definida']);
}
?>