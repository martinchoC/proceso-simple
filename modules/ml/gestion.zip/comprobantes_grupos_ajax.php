<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once "comprobantes_grupos_model.php";

$accion = $_REQUEST['accion'] ?? '';
$empresa_id = intval($_REQUEST['empresa_id'] ?? $_POST['empresa_id'] ?? 0);

header('Content-Type: application/json; charset=utf-8');

switch ($accion) {
    case 'listar':
        if ($empresa_id <= 0) {
            echo json_encode([]);
            break;
        }
        $comprobantes_grupos = obtenerComprobantesGrupos($conexion, $empresa_id);
        echo json_encode($comprobantes_grupos);
        break;
    
    case 'agregar':
        $data = [
            'empresa_id' => $_POST['empresa_id'] ?? 0,
            'comprobante_grupo' => $_POST['comprobante_grupo'] ?? '',
            'estado_registro_id' => $_POST['estado_registro_id'] ?? 1
        ];
        
        if (empty($data['comprobante_grupo']) || $data['empresa_id'] <= 0) {
            echo json_encode(['resultado' => false, 'error' => 'Nombre del grupo es obligatorio']);
            break;
        }
        
        $resultado = agregarComprobanteGrupo($conexion, $data);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'Ya existe un grupo de comprobantes con ese nombre']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'editar':
        $id = intval($_POST['comprobante_grupo_id']);
        $data = [
            'empresa_id' => $_POST['empresa_id'] ?? 0,
            'comprobante_grupo' => $_POST['comprobante_grupo'] ?? '',
            'estado_registro_id' => $_POST['estado_registro_id'] ?? 1
        ];
        
        if (empty($data['comprobante_grupo']) || $data['empresa_id'] <= 0) {
            echo json_encode(['resultado' => false, 'error' => 'Nombre del grupo es obligatorio']);
            break;
        }
        
        $resultado = editarComprobanteGrupo($conexion, $id, $data);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'Ya existe un grupo de comprobantes con ese nombre']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'cambiar_estado':
        $id = intval($_GET['comprobante_grupo_id']);
        $nuevo_estado = intval($_GET['nuevo_estado']);
        $resultado = cambiarEstadoComprobanteGrupo($conexion, $id, $nuevo_estado, $empresa_id);
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'eliminar':
        $id = intval($_GET['comprobante_grupo_id']);
        $resultado = eliminarComprobanteGrupo($conexion, $id, $empresa_id);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'No se puede eliminar el grupo porque tiene tipos de comprobantes asociados']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'obtener':
        $id = intval($_GET['comprobante_grupo_id']);
        $comprobante_grupo = obtenerComprobanteGrupoPorId($conexion, $id, $empresa_id);
        echo json_encode($comprobante_grupo);
        break;

    default:
        echo json_encode(['error' => 'Acción no definida']);
}