<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once "conexion.php";
require_once "comprobantes_tipos_model.php";

$accion = $_REQUEST['accion'] ?? $_POST['accion'] ?? '';
$empresa_id = intval($_REQUEST['empresa_id'] ?? $_POST['empresa_id'] ?? 0);

header('Content-Type: application/json; charset=utf-8');

switch ($accion) {
    case 'listar':
        if ($empresa_id <= 0) {
            echo json_encode([]);
            break;
        }
        $comprobantes_tipos = obtenerComprobantesTipos($conexion, $empresa_id);
        echo json_encode($comprobantes_tipos);
        break;
    
    case 'listar_grupos':
        if ($empresa_id <= 0) {
            echo json_encode([]);
            break;
        }
        $grupos = obtenerComprobantesGruposActivos($conexion, $empresa_id);
        echo json_encode($grupos);
        break;
    
    case 'listar_fiscales':
        $fiscales = obtenerComprobantesFiscalesActivos($conexion);
        echo json_encode($fiscales);
        break;
    
    case 'agregar':
        $data = [
            'comprobante_grupo_id' => $_POST['comprobante_grupo_id'] ?? 0,
            'comprobante_fiscal_id' => $_POST['comprobante_fiscal_id'] ?? 0,
            'impacta_stock' => $_POST['impacta_stock'] ?? 0,
            'impacta_contabilidad' => $_POST['impacta_contabilidad'] ?? 0,
            'impacta_ctacte' => $_POST['impacta_ctacte'] ?? 0,
            'comprobante_tipo' => $_POST['comprobante_tipo'] ?? '',
            'orden' => $_POST['orden'] ?? 0,
            'codigo' => $_POST['codigo'] ?? '',
            'letra' => $_POST['letra'] ?? '',
            'signo' => $_POST['signo'] ?? '+',
            'comentario' => $_POST['comentario'] ?? '',
            'estado_registro_id' => $_POST['estado_registro_id'] ?? 1
        ];
        
        // Elimina la validación de comprobante_fiscal_id
        if (empty($data['comprobante_tipo']) || empty($data['codigo']) || 
            $data['comprobante_grupo_id'] <= 0) {
            echo json_encode(['resultado' => false, 'error' => 'Los campos nombre, código y grupo son obligatorios']);
            break;
        }
        
        $resultado = agregarComprobanteTipo($conexion, $data);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'Ya existe un tipo de comprobante con ese nombre en el grupo seleccionado']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'editar':
        $id = intval($_POST['comprobante_tipo_id']);
        $data = [
            'comprobante_grupo_id' => $_POST['comprobante_grupo_id'] ?? 0,
            'comprobante_fiscal_id' => $_POST['comprobante_fiscal_id'] ?? 0,
            'impacta_stock' => $_POST['impacta_stock'] ?? 0,
            'impacta_contabilidad' => $_POST['impacta_contabilidad'] ?? 0,
            'impacta_ctacte' => $_POST['impacta_ctacte'] ?? 0,
            'orden' => $_POST['orden'] ?? 0,
            'comprobante_tipo' => $_POST['comprobante_tipo'] ?? '',
            'codigo' => $_POST['codigo'] ?? '',
            'letra' => $_POST['letra'] ?? '',
            'signo' => $_POST['signo'] ?? '+',
            'comentario' => $_POST['comentario'] ?? '',
            'estado_registro_id' => $_POST['estado_registro_id'] ?? 1
        ];
        
        // Elimina la validación de comprobante_fiscal_id
        if (empty($data['comprobante_tipo']) || empty($data['codigo']) || 
            $data['comprobante_grupo_id'] <= 0) {
            echo json_encode(['resultado' => false, 'error' => 'Los campos nombre, código y grupo son obligatorios']);
            break;
        }
        
        $resultado = editarComprobanteTipo($conexion, $id, $data);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'Ya existe un tipo de comprobante con ese nombre en el grupo seleccionado']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'cambiar_estado':
        $id = intval($_GET['comprobante_tipo_id']);
        $nuevo_estado = intval($_GET['nuevo_estado']);
        $resultado = cambiarEstadoComprobanteTipo($conexion, $id, $nuevo_estado);
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'eliminar':
        $id = intval($_GET['comprobante_tipo_id']);
        $resultado = eliminarComprobanteTipo($conexion, $id);
        if (!$resultado) {
            echo json_encode(['resultado' => false, 'error' => 'No se puede eliminar el tipo porque tiene comprobantes asociados']);
            break;
        }
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'obtener':
        $id = intval($_GET['comprobante_tipo_id']);
        $comprobante_tipo = obtenerComprobanteTipoPorId($conexion, $id);
        echo json_encode($comprobante_tipo);
        break;

    default:
        echo json_encode(['error' => 'Acción no definida: ' . $accion]);
}
?>