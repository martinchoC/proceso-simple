<?php
require_once "conexion.php";
function obtenerModelos($conexion) {
    $sql = "SELECT m.*, ma.marca_nombre 
            FROM gestion__modelos m 
            INNER JOIN gestion__marcas ma ON m.marca_id = ma.marca_id 
            ORDER BY m.modelo_id DESC";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerMarcas($conexion) {
    $sql = "SELECT * FROM gestion__marcas WHERE estado_registro_id = 1 ORDER BY marca_nombre";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function agregarModelo($conexion, $data) {
    $marca_id = intval($data['marca_id']);
    $modelo_nombre = mysqli_real_escape_string($conexion, $data['modelo_nombre']);
    $estado_registro_id = intval($data['estado_registro_id']);

    $sql = "INSERT INTO gestion__modelos (marca_id, modelo_nombre, estado_registro_id) 
            VALUES ($marca_id, '$modelo_nombre', $estado_registro_id)";

    return mysqli_query($conexion, $sql);
}

function editarModelo($conexion, $id, $data) {
    $id = intval($id);
    $marca_id = intval($data['marca_id']);
    $modelo_nombre = mysqli_real_escape_string($conexion, $data['modelo_nombre']);
    $estado_registro_id = intval($data['estado_registro_id']);

    $sql = "UPDATE gestion__modelos SET
            marca_id=$marca_id,
            modelo_nombre='$modelo_nombre',
            estado_registro_id=$estado_registro_id
            WHERE modelo_id=$id";

    return mysqli_query($conexion, $sql);
}

function eliminarModelo($conexion, $id) {
    $id = intval($id);
    
    // Verificar si hay submodelos asociados
    $check_sql = "SELECT COUNT(*) as count FROM gestion__submodelos WHERE modelo_id = $id";
    $result = mysqli_query($conexion, $check_sql);
    $row = mysqli_fetch_assoc($result);
    
    if ($row['count'] > 0) {
        return false; // No se puede eliminar si hay submodelos asociados
    }
    
    $sql = "DELETE FROM gestion__modelos WHERE modelo_id = $id";
    return mysqli_query($conexion, $sql);
}

function obtenerModeloPorId($conexion, $id) {
    $id = intval($id);
    $sql = "SELECT * FROM gestion__modelos WHERE modelo_id = $id";
    $res = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($res);
}