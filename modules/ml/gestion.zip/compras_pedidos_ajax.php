<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);



require_once "compras_pedidos_model.php";

// Configuración
$empresa_id = 2;
$usuario_id = 1;

// ✅ CORREGIR: Obtener acción de POST o GET
$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';

header('Content-Type: application/json; charset=utf-8');


try {
    // ✅ DEBUG TEMPORAL: Identificar línea del problema
    error_log("=== PROCESANDO ACCIÓN: $accion ===");
    
    switch ($accion) {
        case 'listar':
            $pedidos = obtenerComprasPedidos($conexion, $empresa_id);
            echo json_encode($pedidos);
            break;
        
        case 'obtener_datos_maestros':
            $tipos = obtenerTiposCompraPedido($conexion, $empresa_id);
            $proveedores = obtenerProveedores($conexion, $empresa_id);
            $sucursales = obtenerSucursales($conexion, $empresa_id);
            $productos = obtenerProductos($conexion, $empresa_id);
            
            echo json_encode([
                'tipos' => $tipos,
                'proveedores' => $proveedores,
                'sucursales' => $sucursales,
                'productos' => $productos
            ]);
            break;
        
        case 'obtener_siguiente_numero':
            $sucursal_id = intval($_GET['sucursal_id'] ?? 1);
            $comprobante_tipo_id = intval($_GET['comprobante_tipo_id']);
            
            $siguiente_numero = obtenerSiguienteNumeroComprobante($conexion, $empresa_id, $sucursal_id, $comprobante_tipo_id);
            echo json_encode(['siguiente_numero' => $siguiente_numero]);
            break;
        
        case 'agregar':
            // Log de los datos recibidos
            error_log("Datos recibidos para AGREGAR: " . print_r($_POST, true));
            
            // Validar datos requeridos
            if (empty($_POST['sucursal_id']) || empty($_POST['comprobante_tipo_id']) || empty($_POST['entidad_id'])) {
                $error = "Faltan datos requeridos: sucursal_id, comprobante_tipo_id o entidad_id";
                error_log($error);
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            $data = [
                'empresa_id' => $empresa_id,
                'sucursal_id' => intval($_POST['sucursal_id']),
                'punto_venta_id' => intval($_POST['punto_venta_id'] ?? 1),
                'comprobante_tipo_id' => intval($_POST['comprobante_tipo_id']),
                'numero_comprobante' => intval($_POST['numero_comprobante']),
                'entidad_id' => intval($_POST['entidad_id']),
                'f_emision' => $_POST['f_emision'],
                'f_contabilizacion' => $_POST['f_contabilizacion'],
                'f_vto' => $_POST['f_vto'],
                'observaciones' => $_POST['observaciones'] ?? '',
                'importe_neto' => floatval($_POST['importe_neto'] ?? 0),
                'importe_no_gravado' => floatval($_POST['importe_no_gravado'] ?? 0),
                'total' => floatval($_POST['total'] ?? 0),
                'estado_registro_id' => ESTADO_BORRADOR
            ];
            
            error_log("Data procesada: " . print_r($data, true));
            
            // Procesar detalles
            $detalles = [];
            if (isset($_POST['detalles']) && is_array($_POST['detalles'])) {
                foreach ($_POST['detalles'] as $index => $detalle) {
                    if (empty($detalle['producto_id']) || empty($detalle['cantidad']) || empty($detalle['precio_unitario'])) {
                        $error = "Detalle incompleto en índice $index";
                        error_log($error);
                        echo json_encode(['resultado' => false, 'error' => $error]);
                        break 2;
                    }
                    
                    $detalles[] = [
                        'producto_id' => intval($detalle['producto_id']),
                        'cantidad' => floatval($detalle['cantidad']),
                        'precio_unitario' => floatval($detalle['precio_unitario']),
                        'descuento' => floatval($detalle['descuento'] ?? 0),
                        'estado_registro_id' => ESTADO_BORRADOR
                    ];
                }
            }
            
            error_log("Detalles procesados: " . print_r($detalles, true));
            
            if (empty($detalles)) {
                $error = 'Debe agregar al menos un producto al pedido';
                error_log($error);
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            $resultado = agregarCompraPedido($conexion, $data, $detalles, $usuario_id);
            
            if (!$resultado) {
                $error = 'Error al crear el pedido en la base de datos';
                error_log($error);
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            echo json_encode(['resultado' => true, 'comprobante_id' => $resultado, 'mensaje' => 'Pedido creado como borrador']);
            break;

        case 'obtener_info_estado':
            $comprobante_id = intval($_GET['comprobante_id']);
            
            if (empty($comprobante_id)) {
                echo json_encode(['editable' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $info_estado = obtenerInfoEstadoCompraPedido($conexion, $comprobante_id);
            $editable = esPedidoEditable($conexion, $comprobante_id);
            
            echo json_encode([
                'editable' => $editable,
                'estado_id' => $info_estado['estado_registro_id'],
                'estado_nombre' => $info_estado['estado_registro']
            ]);
            break;
        
        case 'editar':
            $comprobante_id = intval($_POST['comprobante_id']);
            
            if (empty($comprobante_id)) {
                echo json_encode(['resultado' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
            error_log("=== INICIANDO EDICIÓN ===");
            error_log("Editando pedido ID: $comprobante_id, Estado actual: $estado_actual");
            error_log("Datos POST recibidos: " . print_r($_POST, true));
            
            if ($estado_actual != 3 && $estado_actual != 4) {
                $error = "Solo se pueden editar pedidos en estado Borrador (3) o Pendiente (4). Estado actual: " . $estado_actual;
                error_log("ERROR: $error");
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            if (empty($_POST['sucursal_id']) || empty($_POST['comprobante_tipo_id']) || empty($_POST['entidad_id'])) {
                $error = "Faltan datos requeridos: sucursal_id, comprobante_tipo_id o entidad_id";
                error_log("ERROR: $error");
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            $data = [
                'sucursal_id' => intval($_POST['sucursal_id']),
                'punto_venta_id' => intval($_POST['punto_venta_id'] ?? 1),
                'comprobante_tipo_id' => intval($_POST['comprobante_tipo_id']),
                'entidad_id' => intval($_POST['entidad_id']),
                'f_emision' => $_POST['f_emision'],
                'f_contabilizacion' => $_POST['f_contabilizacion'],
                'f_vto' => $_POST['f_vto'],
                'observaciones' => $_POST['observaciones'] ?? '',
                'importe_neto' => floatval($_POST['importe_neto'] ?? 0),
                'importe_no_gravado' => floatval($_POST['importe_no_gravado'] ?? 0),
                'total' => floatval($_POST['total'] ?? 0),
                'estado_registro_id' => $estado_actual
            ];
            
            error_log("Data procesada para edición: " . print_r($data, true));
            
            $detalles = [];
            if (isset($_POST['detalles']) && is_array($_POST['detalles'])) {
                foreach ($_POST['detalles'] as $index => $detalle) {
                    if (empty($detalle['producto_id']) || empty($detalle['cantidad']) || empty($detalle['precio_unitario'])) {
                        $error = "Detalle incompleto en índice $index";
                        error_log("ERROR: $error");
                        echo json_encode(['resultado' => false, 'error' => $error]);
                        break 2;
                    }
                    
                    $detalles[] = [
                        'producto_id' => intval($detalle['producto_id']),
                        'cantidad' => floatval($detalle['cantidad']),
                        'precio_unitario' => floatval($detalle['precio_unitario']),
                        'descuento' => floatval($detalle['descuento'] ?? 0),
                        'estado_registro_id' => 3
                    ];
                }
            }
            
            error_log("Detalles procesados: " . print_r($detalles, true));
            error_log("Total detalles: " . count($detalles));
            
            if (empty($detalles)) {
                $error = 'Debe agregar al menos un producto al pedido';
                error_log("ERROR: $error");
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            $resultado = editarCompraPedido($conexion, $comprobante_id, $data, $detalles, $usuario_id);
            
            if (!$resultado) {
                $error = 'Error al actualizar el pedido. Solo se pueden editar pedidos en estado borrador o pendiente.';
                error_log("ERROR: $error");
                echo json_encode(['resultado' => false, 'error' => $error]);
                break;
            }
            
            error_log("=== EDICIÓN EXITOSA ===");
            echo json_encode(['resultado' => true, 'mensaje' => 'Pedido actualizado correctamente']);
            break;
        
        case 'obtener':
            $comprobante_id = intval($_GET['comprobante_id']);
            
            if (empty($comprobante_id)) {
                echo json_encode(['resultado' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $pedido = obtenerCompraPedidoPorId($conexion, $comprobante_id);
            $detalles = obtenerDetallesCompraPedido($conexion, $comprobante_id);
            
            if (!$pedido) {
                echo json_encode(['resultado' => false, 'error' => 'Pedido no encontrado']);
                break;
            }
            
            echo json_encode([
                'pedido' => $pedido,
                'detalles' => $detalles
            ]);
            break;
        
        case 'confirmar':
            $comprobante_id = intval($_POST['comprobante_id']);
            
            if (empty($comprobante_id)) {
                echo json_encode(['resultado' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
            error_log("Solicitando confirmación para pedido ID: $comprobante_id, Estado actual: $estado_actual");
            
            $resultado = confirmarCompraPedido($conexion, $comprobante_id, $usuario_id);
            if (!$resultado) {
                $error_msg = 'Error al confirmar el pedido. ';
                if ($estado_actual == ESTADO_CONFIRMADO) {
                    $error_msg .= 'El pedido ya está confirmado.';
                } else if ($estado_actual == ESTADO_ELIMINADO) {
                    $error_msg .= 'No se puede confirmar un pedido eliminado.';
                } else {
                    $error_msg .= 'Solo se pueden confirmar pedidos en estado Borrador o Pendiente.';
                }
                echo json_encode(['resultado' => false, 'error' => $error_msg]);
                break;
            }
            echo json_encode(['resultado' => true, 'mensaje' => 'Pedido confirmado correctamente']);
            break;

        case 'pendiente':
            // ✅ CORREGIR: Usar $_GET y valor por defecto
            $comprobante_id = intval($_POST['comprobante_id']);
            
            if (empty($comprobante_id)) {
                echo json_encode(['resultado' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
            error_log("Solicitando cambio a pendiente para pedido ID: $comprobante_id, Estado actual: $estado_actual");
            
            $resultado = pendienteCompraPedido($conexion, $comprobante_id, $usuario_id);
            if (!$resultado) {
                $error_msg = 'Error al cambiar a pendiente. ';
                if ($estado_actual == ESTADO_PENDIENTE) {
                    $error_msg .= 'El pedido ya está pendiente.';
                } else if ($estado_actual != ESTADO_BORRADOR) {
                    $error_msg .= 'Solo se pueden marcar como pendiente pedidos en estado Borrador.';
                } else {
                    $error_msg .= 'No se pudo cambiar el estado del pedido.';
                }
                echo json_encode(['resultado' => false, 'error' => $error_msg]);
                break;
            }
            echo json_encode(['resultado' => true, 'mensaje' => 'Pedido marcado como pendiente']);
            break;

        case 'eliminar':
            $comprobante_id = intval($_POST['comprobante_id']);
            
            if (empty($comprobante_id)) {
                echo json_encode(['resultado' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
            error_log("Solicitando eliminación para pedido ID: $comprobante_id, Estado actual: $estado_actual");
            
            $resultado = eliminarCompraPedido($conexion, $comprobante_id, $usuario_id);
            
            if (!$resultado) {
                $error_msg = 'Error al eliminar el pedido. ';
                if ($estado_actual == ESTADO_ELIMINADO) {
                    $error_msg .= 'El pedido ya está eliminado.';
                } else {
                    $error_msg .= 'No se pudo eliminar el pedido.';
                }
                echo json_encode(['resultado' => false, 'error' => $error_msg]);
                break;
            }
            echo json_encode(['resultado' => true, 'mensaje' => 'Pedido eliminado correctamente']);
            break;
        
        case 'cambiar_estado':
            $comprobante_id = intval($_POST['comprobante_id']);
            $nuevo_estado = intval($_GET['nuevo_estado'] ?? 0);
            
            if (empty($comprobante_id)) {
                echo json_encode(['resultado' => false, 'error' => 'ID de comprobante no válido']);
                break;
            }
            
            $resultado = cambiarEstadoCompraPedido($conexion, $comprobante_id, $nuevo_estado);
            echo json_encode(['resultado' => $resultado]);
            break;

        

        default:
            echo json_encode(['error' => 'Acción no definida: ' . $accion]);
    }
} catch (Exception $e) {
    error_log("EXCEPCIÓN en compras_pedidos_ajax: " . $e->getMessage());
    echo json_encode(['resultado' => false, 'error' => 'Error del servidor: ' . $e->getMessage()]);
}

// Cerrar conexión si existe
if (isset($conexion)) {
    mysqli_close($conexion);
}
?>