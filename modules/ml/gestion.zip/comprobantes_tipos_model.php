<?php
require_once "conexion.php";

function obtenerComprobantesTipos($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT 
                ct.*,
                cg.comprobante_grupo,
                IFNULL(cf.comprobante_fiscal, 'Sin tipo fiscal') as comprobante_fiscal
            FROM `gestion__comprobantes_tipos` ct
            LEFT JOIN `gestion__comprobantes_grupos` cg ON ct.comprobante_grupo_id = cg.comprobante_grupo_id
            LEFT JOIN `gestion__comprobantes_fiscales` cf ON ct.comprobante_fiscal_id = cf.comprobante_fiscal_id
            WHERE cg.empresa_id = $empresa_id 
            ORDER BY cg.comprobante_grupo_id, ct.orden, ct.comprobante_tipo";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerComprobantesGruposActivos($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT * FROM `gestion__comprobantes_grupos` 
            WHERE empresa_id = $empresa_id 
            AND estado_registro_id = 1
            ORDER BY comprobante_grupo";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerComprobantesFiscalesActivos($conexion) {
    $sql = "SELECT * FROM `gestion__comprobantes_fiscales` 
            WHERE estado_registro_id = 1
            ORDER BY comprobante_fiscal";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function agregarComprobanteTipo($conexion, $data) {
    if (empty($data['comprobante_tipo']) || empty($data['codigo']) || empty($data['comprobante_grupo_id'])) {
        return false;
    }
    
    $comprobante_tipo = mysqli_real_escape_string($conexion, $data['comprobante_tipo']);
    $codigo = mysqli_real_escape_string($conexion, $data['codigo']);
    $letra = mysqli_real_escape_string($conexion, $data['letra'] ?? '');
    $comentario = mysqli_real_escape_string($conexion, $data['comentario'] ?? '');
    $comprobante_grupo_id = intval($data['comprobante_grupo_id']);
    $comprobante_fiscal_id = intval($data['comprobante_fiscal_id']);
    $orden = intval($data['orden'] ?? 0);
    $impacta_stock = intval($data['impacta_stock'] ?? 0);
    $impacta_contabilidad = intval($data['impacta_contabilidad'] ?? 0);
    $impacta_ctacte = intval($data['impacta_ctacte'] ?? 0);
    $signo = mysqli_real_escape_string($conexion, $data['signo'] ?? '+');
    $estado_registro_id = intval($data['estado_registro_id'] ?? 1);

    // Verificar si ya existe el tipo para este grupo
    $sql_check = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_tipos` 
                  WHERE comprobante_tipo = '$comprobante_tipo' 
                  AND comprobante_grupo_id = $comprobante_grupo_id";
    $res_check = mysqli_query($conexion, $sql_check);
    $existe = mysqli_fetch_assoc($res_check)['existe'];
    
    if ($existe > 0) {
        return false; // Ya existe este tipo para este grupo
    }

    $sql = "INSERT INTO `gestion__comprobantes_tipos` 
            (comprobante_grupo_id, comprobante_fiscal_id, orden, impacta_stock, impacta_contabilidad, 
             impacta_ctacte, comprobante_tipo, codigo, letra, signo, comentario, estado_registro_id) 
            VALUES 
            ($comprobante_grupo_id, $comprobante_fiscal_id, $orden, $impacta_stock, $impacta_contabilidad,
             $impacta_ctacte, '$comprobante_tipo', '$codigo', '$letra', '$signo', '$comentario', $estado_registro_id)";
    
    return mysqli_query($conexion, $sql);
}

function editarComprobanteTipo($conexion, $id, $data) {
    if (empty($data['comprobante_tipo']) || empty($data['codigo']) || empty($data['comprobante_grupo_id'])) {
        return false;
    }
    
    $id = intval($id);
    $comprobante_tipo = mysqli_real_escape_string($conexion, $data['comprobante_tipo']);
    $codigo = mysqli_real_escape_string($conexion, $data['codigo']);
    $letra = mysqli_real_escape_string($conexion, $data['letra'] ?? '');
    $comentario = mysqli_real_escape_string($conexion, $data['comentario'] ?? '');
    $comprobante_grupo_id = intval($data['comprobante_grupo_id']);
    $comprobante_fiscal_id = intval($data['comprobante_fiscal_id']);
    $orden = intval($data['orden'] ?? 0);
    $impacta_stock = intval($data['impacta_stock'] ?? 0);
    $impacta_contabilidad = intval($data['impacta_contabilidad'] ?? 0);
    $impacta_ctacte = intval($data['impacta_ctacte'] ?? 0);
    $signo = mysqli_real_escape_string($conexion, $data['signo'] ?? '+');
    $estado_registro_id = intval($data['estado_registro_id'] ?? 1);

    // Verificar si ya existe el tipo (excluyendo el registro actual)
    $sql_check = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_tipos` 
                  WHERE comprobante_tipo = '$comprobante_tipo' 
                  AND comprobante_grupo_id = $comprobante_grupo_id
                  AND comprobante_tipo_id != $id";
    $res_check = mysqli_query($conexion, $sql_check);
    $existe = mysqli_fetch_assoc($res_check)['existe'];
    
    if ($existe > 0) {
        return false; // Ya existe este tipo para este grupo
    }

    $sql = "UPDATE `gestion__comprobantes_tipos` SET
            comprobante_grupo_id = $comprobante_grupo_id,
            comprobante_fiscal_id = $comprobante_fiscal_id,
            orden = $orden,
            impacta_stock = $impacta_stock,
            impacta_contabilidad = $impacta_contabilidad,
            impacta_ctacte = $impacta_ctacte,
            comprobante_tipo = '$comprobante_tipo',
            codigo = '$codigo',
            letra = '$letra',
            signo = '$signo',
            comentario = '$comentario',
            estado_registro_id = $estado_registro_id
            WHERE comprobante_tipo_id = $id";

    return mysqli_query($conexion, $sql);
}

function cambiarEstadoComprobanteTipo($conexion, $id, $nuevo_estado) {
    $id = intval($id);
    $nuevo_estado = intval($nuevo_estado);
    
    $sql = "UPDATE `gestion__comprobantes_tipos` 
            SET estado_registro_id = $nuevo_estado 
            WHERE comprobante_tipo_id = $id";
    return mysqli_query($conexion, $sql);
}

function eliminarComprobanteTipo($conexion, $id) {
    $id = intval($id);
    
    // Verificar si hay comprobantes asociados (dependiendo de tu estructura)
    // $sql_check = "SELECT COUNT(*) as tiene_comprobantes FROM `gestion__comprobantes` 
    //               WHERE comprobante_tipo_id = $id";
    // $res_check = mysqli_query($conexion, $sql_check);
    // $tiene_comprobantes = mysqli_fetch_assoc($res_check)['tiene_comprobantes'];
    
    // if ($tiene_comprobantes > 0) {
    //     return false; // No se puede eliminar porque tiene comprobantes asociados
    // }
    
    $sql = "DELETE FROM `gestion__comprobantes_tipos` 
            WHERE comprobante_tipo_id = $id";
    return mysqli_query($conexion, $sql);
}

function obtenerComprobanteTipoPorId($conexion, $id) {
    $id = intval($id);
    $sql = "SELECT * FROM `gestion__comprobantes_tipos` 
            WHERE comprobante_tipo_id = $id";
    $res = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($res);
}
?>