<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once "modelos_model.php";

$accion = $_GET['accion'] ?? '';

header('Content-Type: application/json; charset=utf-8');

switch ($accion) {
    case 'listar':
        $modelos = obtenerModelos($conexion);
        echo json_encode($modelos);
        break;

    case 'agregar':
        $data = [
            'marca_id' => $_GET['marca_id'] ?? '',
            'modelo_nombre' => $_GET['modelo_nombre'] ?? '',
            'estado_registro_id' => $_GET['estado_registro_id'] ?? 1
        ];
        $resultado = agregarModelo($conexion, $data);
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'editar':
        $id = intval($_GET['modelo_id']);
        $data = [
            'marca_id' => $_GET['marca_id'] ?? '',
            'modelo_nombre' => $_GET['modelo_nombre'] ?? '',
            'estado_registro_id' => $_GET['estado_registro_id'] ?? 1
        ];
        $resultado = editarModelo($conexion, $id, $data);
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'eliminar':
        $id = intval($_GET['modelo_id']);
        $resultado = eliminarModelo($conexion, $id);
        echo json_encode(['resultado' => $resultado]);
        break;

    case 'obtener':
        $id = intval($_GET['modelo_id']);
        $modelo = obtenerModeloPorId($conexion, $id);
        echo json_encode($modelo);
        break;

    default:
        echo json_encode(['error' => 'Acción no definida']);
}