<?php
require_once "conexion.php";

// Definir estados según la tabla conf__estados_registros
define('ESTADO_BORRADOR', 3);     // borrador
define('ESTADO_PENDIENTE', 7);    // pendiente  
define('ESTADO_ELIMINADO', 6);    // eliminado

function obtenerComprasPedidos($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT 
                c.comprobante_id,
                c.numero_comprobante,
                c.f_emision,
                c.f_vto,
                e.entidad_nombre as proveedor,
                s.sucursal_nombre,
                ct.comprobante_tipo,
                c.total,
                c.estado_registro_id,
                er.estado_registro as estado_nombre,
                CASE 
                    WHEN c.estado_registro_id = 3 THEN 'Borrador'
                    WHEN c.estado_registro_id = 7 THEN 'Pendiente de Recepcion'                    
                    WHEN c.estado_registro_id = 6 THEN 'Eliminado'
                    ELSE er.estado_registro
                END as estado_display
            FROM `gestion__comprobantes` c
            INNER JOIN `gestion__comprobantes_tipos` ct ON c.comprobante_tipo_id = ct.comprobante_tipo_id
            LEFT JOIN `gestion__entidades` e ON c.entidad_id = e.entidad_id
            LEFT JOIN `gestion__sucursales` s ON c.sucursal_id = s.sucursal_id
            LEFT JOIN `conf__estados_registros` er ON c.estado_registro_id = er.estado_registro_id
            WHERE c.empresa_id = $empresa_id 
            AND ct.comprobante_grupo_id = 2 -- Suponiendo que 3 es el grupo para pedidos a proveedores
            AND c.estado_registro_id != " . ESTADO_ELIMINADO . " -- Excluir eliminados
            ORDER BY c.f_emision DESC, c.numero_comprobante DESC";
    
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerTiposCompraPedido($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT comprobante_tipo_id, comprobante_tipo, codigo
            FROM `gestion__comprobantes_tipos`
            WHERE empresa_id = $empresa_id 
            AND comprobante_grupo_id = 2 -- Grupo para pedidos a proveedores
            AND estado_registro_id = 1
            ORDER BY orden";
    
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerProveedores($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT entidad_id, entidad_nombre
            FROM `gestion__entidades`
            WHERE empresa_id = $empresa_id 
            AND es_proveedor = 1
            AND estado_registro_id = 1
            ORDER BY entidad_nombre";
    
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerSucursales($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT sucursal_id, sucursal_nombre
            FROM `gestion__sucursales`
            WHERE empresa_id = $empresa_id 
            AND estado_registro_id = 1
            ORDER BY sucursal_nombre";
    
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerProductos($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT producto_id, producto_nombre, codigo_barras
            FROM `gestion__productos`
            WHERE empresa_id = $empresa_id 
            AND estado_registro_id = 1
            ORDER BY producto_nombre";
    
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function obtenerSiguienteNumeroComprobante($conexion, $empresa_id, $sucursal_id, $comprobante_tipo_id) {
    $empresa_id = intval($empresa_id);
    $sucursal_id = intval($sucursal_id);
    $comprobante_tipo_id = intval($comprobante_tipo_id);
    
    $sql = "SELECT COALESCE(MAX(numero_comprobante), 0) + 1 as siguiente_numero
            FROM `gestion__comprobantes`
            WHERE empresa_id = $empresa_id 
            AND sucursal_id = $sucursal_id
            AND comprobante_tipo_id = $comprobante_tipo_id";
    
    $res = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_assoc($res);
    return $fila['siguiente_numero'];
}

function agregarCompraPedido($conexion, $data, $detalles, $usuario_id) {
    mysqli_begin_transaction($conexion);
    
    try {
        // Insertar comprobante principal - SIEMPRE como BORRADOR (estado 3)
        $sql_comprobante = "INSERT INTO `gestion__comprobantes` 
            (empresa_id, sucursal_id, punto_venta_id, comprobante_tipo_id, 
             numero_comprobante, entidad_id, f_emision, f_contabilizacion, f_vto,
             observaciones, importe_neto, importe_no_gravado, total,
             estado_registro_id, creado_por, creado_en)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = mysqli_prepare($conexion, $sql_comprobante);
        
        if (!$stmt) {
            throw new Exception("Error al preparar la consulta: " . mysqli_error($conexion));
        }
        
        mysqli_stmt_bind_param($stmt, "iiiiisssssdddii", 
            $data['empresa_id'], 
            $data['sucursal_id'], 
            $data['punto_venta_id'],
            $data['comprobante_tipo_id'], 
            $data['numero_comprobante'], 
            $data['entidad_id'],
            $data['f_emision'], 
            $data['f_contabilizacion'], 
            $data['f_vto'],
            $data['observaciones'], 
            $data['importe_neto'], 
            $data['importe_no_gravado'],
            $data['total'], 
            $data['estado_registro_id'], 
            $usuario_id
        );
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Error al insertar comprobante: " . mysqli_error($conexion));
        }
        
        $comprobante_id = mysqli_insert_id($conexion);
        
        // Insertar detalles
        foreach ($detalles as $detalle) {
            $sql_detalle = "INSERT INTO `gestion__comprobantes_detalles`
                (comprobante_id, producto_id, cantidad, precio_unitario, descuento, estado_registro_id)
                VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt_detalle = mysqli_prepare($conexion, $sql_detalle);
            
            if (!$stmt_detalle) {
                throw new Exception("Error al preparar consulta de detalle: " . mysqli_error($conexion));
            }
            
            mysqli_stmt_bind_param($stmt_detalle, "iidddi",
                $comprobante_id, 
                $detalle['producto_id'], 
                $detalle['cantidad'],
                $detalle['precio_unitario'], 
                $detalle['descuento'], 
                $detalle['estado_registro_id']
            );
            
            if (!mysqli_stmt_execute($stmt_detalle)) {
                throw new Exception("Error al insertar detalle: " . mysqli_error($conexion));
            }
        }
        
        mysqli_commit($conexion);
        return $comprobante_id;
        
    } catch (Exception $e) {
        mysqli_rollback($conexion);
        error_log("Error en agregarCompraPedido: " . $e->getMessage());
        return false;
    }
}

function obtenerCompraPedidoPorId($conexion, $comprobante_id) {
    $comprobante_id = intval($comprobante_id);
    
    $sql = "SELECT c.*, ct.comprobante_tipo, e.entidad_nombre, s.sucursal_nombre
            FROM `gestion__comprobantes` c
            INNER JOIN `gestion__comprobantes_tipos` ct ON c.comprobante_tipo_id = ct.comprobante_tipo_id
            LEFT JOIN `gestion__entidades` e ON c.entidad_id = e.entidad_id
            LEFT JOIN `gestion__sucursales` s ON c.sucursal_id = s.sucursal_id
            WHERE c.comprobante_id = $comprobante_id";
    
    $res = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($res);
}

function obtenerDetallesCompraPedido($conexion, $comprobante_id) {
    $comprobante_id = intval($comprobante_id);
    
    $sql = "SELECT cd.*, p.producto_nombre, p.codigo_barras
            FROM `gestion__comprobantes_detalles` cd
            LEFT JOIN `gestion__productos` p ON cd.producto_id = p.producto_id
            WHERE cd.comprobante_id = $comprobante_id
            AND cd.estado_registro_id = " . ESTADO_BORRADOR; // Solo detalles activos (borrador)
    
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function editarCompraPedido($conexion, $comprobante_id, $data, $detalles, $usuario_id) {
    // Verificar estado actual
    $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
    error_log("Editando pedido ID: $comprobante_id, Estado actual: $estado_actual");
    
    // Permitir editar solo si está en borrador (3) o pendiente (4)
    if ($estado_actual != 3 && $estado_actual != 4) {
        error_log("Intento de editar pedido no editable. ID: $comprobante_id, Estado: $estado_actual");
        return false;
    }
    
    mysqli_begin_transaction($conexion);
    
    try {
        // CORREGIDO: Consulta SQL con WHERE simplificado
        $sql_comprobante = "UPDATE `gestion__comprobantes` SET
            sucursal_id = ?,
            punto_venta_id = ?,
            comprobante_tipo_id = ?, 
            entidad_id = ?, 
            f_emision = ?, 
            f_contabilizacion = ?, 
            f_vto = ?, 
            observaciones = ?,
            importe_neto = ?, 
            importe_no_gravado = ?, 
            total = ?,
            estado_registro_id = ?,
            actualizado_por = ?, 
            actualizado_en = NOW()
            WHERE comprobante_id = ?";
        
        $stmt = mysqli_prepare($conexion, $sql_comprobante);
        
        if (!$stmt) {
            throw new Exception("Error al preparar consulta de actualización: " . mysqli_error($conexion));
        }
        
        // CORREGIDO: Bind parameters sin las condiciones adicionales en WHERE
        mysqli_stmt_bind_param($stmt, "iiisssssdddiii",
            $data['sucursal_id'],
            $data['punto_venta_id'],
            $data['comprobante_tipo_id'], 
            $data['entidad_id'], 
            $data['f_emision'],
            $data['f_contabilizacion'], 
            $data['f_vto'], 
            $data['observaciones'],
            $data['importe_neto'], 
            $data['importe_no_gravado'], 
            $data['total'],
            $data['estado_registro_id'],
            $usuario_id, 
            $comprobante_id
        );
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Error al actualizar comprobante: " . mysqli_error($conexion));
        }
        
        $filas_afectadas = mysqli_stmt_affected_rows($stmt);
        error_log("Filas afectadas en actualización: $filas_afectadas");
        
        // Verificar que se actualizó alguna fila
        if ($filas_afectadas === 0) {
            throw new Exception("No se pudo actualizar el pedido.");
        }
        
        // Eliminar detalles existentes (soft delete)
        $sql_delete_detalles = "UPDATE `gestion__comprobantes_detalles` 
                               SET estado_registro_id = 6 
                               WHERE comprobante_id = ? AND estado_registro_id IN (3,4)";
        $stmt_delete = mysqli_prepare($conexion, $sql_delete_detalles);
        mysqli_stmt_bind_param($stmt_delete, "i", $comprobante_id);
        
        if (!mysqli_stmt_execute($stmt_delete)) {
            throw new Exception("Error al eliminar detalles anteriores: " . mysqli_error($conexion));
        }
        
        // Insertar nuevos detalles
        foreach ($detalles as $detalle) {
            $sql_detalle = "INSERT INTO `gestion__comprobantes_detalles`
                (comprobante_id, producto_id, cantidad, precio_unitario, descuento, estado_registro_id)
                VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt_detalle = mysqli_prepare($conexion, $sql_detalle);
            if (!$stmt_detalle) {
                throw new Exception("Error al preparar consulta de detalle: " . mysqli_error($conexion));
            }
            
            mysqli_stmt_bind_param($stmt_detalle, "iidddi",
                $comprobante_id, 
                $detalle['producto_id'], 
                $detalle['cantidad'],
                $detalle['precio_unitario'], 
                $detalle['descuento'], 
                $detalle['estado_registro_id']
            );
            
            if (!mysqli_stmt_execute($stmt_detalle)) {
                throw new Exception("Error al insertar detalle: " . mysqli_error($conexion));
            }
        }
        
        mysqli_commit($conexion);
        error_log("Edición completada exitosamente para pedido ID: $comprobante_id");
        return true;
        
    } catch (Exception $e) {
        mysqli_rollback($conexion);
        error_log("Error en editarCompraPedido: " . $e->getMessage());
        return false;
    }
}

// ✅ AGREGAR: Función para verificar si un pedido es editable
function esPedidoEditable($conexion, $comprobante_id) {
    $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
    return ($estado_actual == 3 || $estado_actual == 4);
}
// ✅ MEJORAR: Función para obtener información completa del estado
function obtenerInfoEstadoCompraPedido($conexion, $comprobante_id) {
    $comprobante_id = intval($comprobante_id);
    $sql = "SELECT c.estado_registro_id, er.estado_registro 
            FROM `gestion__comprobantes` c
            LEFT JOIN `conf__estados_registros` er ON c.estado_registro_id = er.estado_registro_id
            WHERE c.comprobante_id = $comprobante_id";
    
    $res = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($res);
}

function confirmarCompraPedido($conexion, $comprobante_id, $usuario_id) {
    $comprobante_id = intval($comprobante_id);
    
    // ✅ AGREGAR: Verificar estado actual primero
    $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
    error_log("Confirmando pedido ID: $comprobante_id, Estado actual: $estado_actual");
    
    // ✅ CORREGIR: Permitir confirmar desde borrador (3) o pendiente (4)
    if ($estado_actual != 3 && $estado_actual != 4) {
        error_log("No se puede confirmar pedido ID: $comprobante_id. Estado actual: $estado_actual");
        return false;
    }
    
    // ✅ CORREGIR: SQL actualizado - ELIMINAR LAS CONDICIONES DEL WHERE
    $sql = "UPDATE `gestion__comprobantes` 
            SET estado_registro_id = 5, 
                actualizado_por = ?, 
                actualizado_en = NOW()
            WHERE comprobante_id = ?"; // Solo el ID, sin condiciones de estado
    
    $stmt = mysqli_prepare($conexion, $sql);
    if (!$stmt) {
        error_log("Error al preparar consulta de confirmación: " . mysqli_error($conexion));
        return false;
    }
    
    // CORREGIR: Solo 2 parámetros
    mysqli_stmt_bind_param($stmt, "ii", $usuario_id, $comprobante_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Error al ejecutar confirmación: " . mysqli_error($conexion));
        return false;
    }
    
    $filas_afectadas = mysqli_stmt_affected_rows($stmt);
    error_log("Filas afectadas en confirmación: $filas_afectadas");
    
    return $filas_afectadas > 0;
}
function pendienteCompraPedido($conexion, $comprobante_id, $usuario_id) {
    $comprobante_id = intval($comprobante_id);
    
    // ✅ AGREGAR: Verificar estado actual primero
    $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
    error_log("Marcando como pendiente pedido ID: $comprobante_id, Estado actual: $estado_actual");
    
    // ✅ CORREGIR: Solo cambiar si está en borrador (3)
    if ($estado_actual != 3) {
        error_log("No se puede marcar como pendiente pedido ID: $comprobante_id. Estado actual: $estado_actual");
        return false;
    }
    
    // CORREGIR: SQL simplificado
    $sql = "UPDATE `gestion__comprobantes` 
            SET estado_registro_id = ?, 
                actualizado_por = ?, 
                actualizado_en = NOW()
            WHERE comprobante_id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    if (!$stmt) {
        error_log("Error al preparar consulta de pendiente: " . mysqli_error($conexion));
        return false;
    }
    
    // CORREGIR: Solo 3 parámetros
    mysqli_stmt_bind_param($stmt, "iii", ESTADO_PENDIENTE, $usuario_id, $comprobante_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Error al ejecutar cambio a pendiente: " . mysqli_error($conexion));
        return false;
    }
    
    $filas_afectadas = mysqli_stmt_affected_rows($stmt);
    error_log("Filas afectadas en cambio a pendiente: $filas_afectadas");
    
    return $filas_afectadas > 0;
}
function eliminarCompraPedido($conexion, $comprobante_id, $usuario_id) {
    $comprobante_id = intval($comprobante_id);
    
    // ✅ AGREGAR: Verificar estado actual primero
    $estado_actual = obtenerEstadoCompraPedido($conexion, $comprobante_id);
    error_log("Eliminando pedido ID: $comprobante_id, Estado actual: $estado_actual");
    
    // ✅ MEJORAR: No permitir eliminar si ya está eliminado
    if ($estado_actual == ESTADO_ELIMINADO) {
        error_log("Pedido ID: $comprobante_id ya está eliminado");
        return false;
    }
    
    // CORREGIR: SQL simplificado
    $sql = "UPDATE `gestion__comprobantes` 
            SET estado_registro_id = ?, 
                actualizado_por = ?, 
                actualizado_en = NOW()
            WHERE comprobante_id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    if (!$stmt) {
        error_log("Error al preparar consulta de eliminación: " . mysqli_error($conexion));
        return false;
    }
    
    // CORREGIR: Solo 3 parámetros
    mysqli_stmt_bind_param($stmt, "iii", ESTADO_ELIMINADO, $usuario_id, $comprobante_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Error al ejecutar eliminación: " . mysqli_error($conexion));
        return false;
    }
    
    $filas_afectadas = mysqli_stmt_affected_rows($stmt);
    error_log("Filas afectadas en eliminación: $filas_afectadas");
    
    return $filas_afectadas > 0;
}
function cambiarEstadoCompraPedido($conexion, $comprobante_id, $nuevo_estado) {
    $comprobante_id = intval($comprobante_id);
    $nuevo_estado = intval($nuevo_estado);
    
    $sql = "UPDATE `gestion__comprobantes` 
            SET estado_registro_id = ? 
            WHERE comprobante_id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $nuevo_estado, $comprobante_id);
    return mysqli_stmt_execute($stmt);
}

function obtenerEstadoCompraPedido($conexion, $comprobante_id) {
    $comprobante_id = intval($comprobante_id);
    $sql = "SELECT estado_registro_id FROM `gestion__comprobantes` WHERE comprobante_id = $comprobante_id";
    $res = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_assoc($res);
    return $fila ? $fila['estado_registro_id'] : null;
}
?>