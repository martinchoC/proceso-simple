<?php
require_once "conexion.php";

function obtenerComprobantesGrupos($conexion, $empresa_id) {
    $empresa_id = intval($empresa_id);
    $sql = "SELECT * FROM `gestion__comprobantes_grupos` 
            WHERE empresa_id = $empresa_id 
            ORDER BY comprobante_grupo";
    $res = mysqli_query($conexion, $sql);
    $data = [];
    while ($fila = mysqli_fetch_assoc($res)) {
        $data[] = $fila;
    }
    return $data;
}

function agregarComprobanteGrupo($conexion, $data) {
    if (empty($data['comprobante_grupo']) || empty($data['empresa_id'])) {
        return false;
    }
    
    $comprobante_grupo = mysqli_real_escape_string($conexion, $data['comprobante_grupo']);
    $empresa_id = intval($data['empresa_id']);
    $estado_registro_id = intval($data['estado_registro_id']);

    // Verificar si ya existe el grupo para esta empresa
    $sql_check = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_grupos` 
                  WHERE comprobante_grupo = '$comprobante_grupo' 
                  AND empresa_id = $empresa_id";
    $res_check = mysqli_query($conexion, $sql_check);
    $existe = mysqli_fetch_assoc($res_check)['existe'];
    
    if ($existe > 0) {
        return false; // Ya existe este grupo para esta empresa
    }

    $sql = "INSERT INTO `gestion__comprobantes_grupos` 
            (empresa_id, comprobante_grupo, estado_registro_id) 
            VALUES 
            ($empresa_id, '$comprobante_grupo', $estado_registro_id)";
    
    return mysqli_query($conexion, $sql);
}

function editarComprobanteGrupo($conexion, $id, $data) {
    if (empty($data['comprobante_grupo']) || empty($data['empresa_id'])) {
        return false;
    }
    
    $id = intval($id);
    $comprobante_grupo = mysqli_real_escape_string($conexion, $data['comprobante_grupo']);
    $empresa_id = intval($data['empresa_id']);
    $estado_registro_id = intval($data['estado_registro_id']);

    // Verificar si ya existe el grupo (excluyendo el registro actual)
    $sql_check = "SELECT COUNT(*) as existe FROM `gestion__comprobantes_grupos` 
                  WHERE comprobante_grupo = '$comprobante_grupo' 
                  AND empresa_id = $empresa_id
                  AND comprobante_grupo_id != $id";
    $res_check = mysqli_query($conexion, $sql_check);
    $existe = mysqli_fetch_assoc($res_check)['existe'];
    
    if ($existe > 0) {
        return false; // Ya existe este grupo para esta empresa
    }

    $sql = "UPDATE `gestion__comprobantes_grupos` SET
            comprobante_grupo = '$comprobante_grupo',
            estado_registro_id = $estado_registro_id
            WHERE comprobante_grupo_id = $id 
            AND empresa_id = $empresa_id";

    return mysqli_query($conexion, $sql);
}

function cambiarEstadoComprobanteGrupo($conexion, $id, $nuevo_estado, $empresa_id) {
    $id = intval($id);
    $nuevo_estado = intval($nuevo_estado);
    $empresa_id = intval($empresa_id);
    
    $sql = "UPDATE `gestion__comprobantes_grupos` 
            SET estado_registro_id = $nuevo_estado 
            WHERE comprobante_grupo_id = $id 
            AND empresa_id = $empresa_id";
    return mysqli_query($conexion, $sql);
}

function eliminarComprobanteGrupo($conexion, $id, $empresa_id) {
    $id = intval($id);
    $empresa_id = intval($empresa_id);
    
    // Verificar si hay tipos de comprobantes asociados
    $sql_check = "SELECT COUNT(*) as tiene_tipos FROM `gestion__comprobantes_tipos` 
                  WHERE comprobante_grupo_id = $id";
    $res_check = mysqli_query($conexion, $sql_check);
    $tiene_tipos = mysqli_fetch_assoc($res_check)['tiene_tipos'];
    
    if ($tiene_tipos > 0) {
        return false; // No se puede eliminar porque tiene tipos asociados
    }
    
    $sql = "DELETE FROM `gestion__comprobantes_grupos` 
            WHERE comprobante_grupo_id = $id 
            AND empresa_id = $empresa_id";
    return mysqli_query($conexion, $sql);
}

function obtenerComprobanteGrupoPorId($conexion, $id, $empresa_id) {
    $id = intval($id);
    $empresa_id = intval($empresa_id);
    $sql = "SELECT * FROM `gestion__comprobantes_grupos` 
            WHERE comprobante_grupo_id = $id 
            AND empresa_id = $empresa_id";
    $res = mysqli_query($conexion, $sql);
    return mysqli_fetch_assoc($res);
}