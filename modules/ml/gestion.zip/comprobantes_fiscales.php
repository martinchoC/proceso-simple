<?php
// Configuración de la página
$pageTitle = "Gestión de Comprobantes Fiscales";
$currentPage = 'paginas';
$modudo_idx = 2;
$empresa_idx = 2;

// Definir constante para rutas
define('ROOT_PATH', dirname(dirname(dirname(__FILE__))));

// Incluir header
require_once ROOT_PATH . '/templates/adminlte/header1.php';
?>

<main class="app-main">
    <div class="app-content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6"><h3 class="mb-0">Comprobantes Fiscales</h3></div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Comprobantes Fiscales</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="app-content">
        <div class="container-fluid">
            <div class="content-wrapper">
                <section class="content">
                    <div class="container-fluid">                      
                        <div class="row">
                            <div class="col-12">
                                <div class="card">                                
                                    <div class="card-body">
                                        <button class="btn btn-primary mb-3" id="btnNuevo">Nuevo Comprobante Fiscal</button>
                                        <table id="tablaComprobantesFiscales" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Código</th>
                                                    <th>Comprobante Fiscal</th>
                                                    <th>Estado</th>
                                                    <th>Acciones</th>
                                                </tr>                                            
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Modal -->
            <div class="modal fade" id="modalComprobanteFiscal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalLabel">Comprobante Fiscal</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                        </div>
                        <div class="modal-body">
                            <form id="formComprobanteFiscal">
                                <input type="hidden" id="comprobante_fiscal_id" name="comprobante_fiscal_id" />
                                
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label>Código *</label>
                                        <input type="number" class="form-control" id="codigo" name="codigo" 
                                               min="1" max="255" required />
                                        <div class="invalid-feedback">El código es obligatorio (1-255)</div>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Nombre del Comprobante Fiscal *</label>
                                        <input type="text" class="form-control" id="comprobante_fiscal" 
                                               name="comprobante_fiscal" required maxlength="50"/>
                                        <div class="invalid-feedback">El nombre es obligatorio</div>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Estado</label>
                                        <select class="form-control" id="estado_registro_id" name="estado_registro_id">
                                            <option value="1">Activo</option>
                                            <option value="0">Inactivo</option>
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="alert alert-info">
                                            <small>
                                                <strong>Información:</strong> Los comprobantes fiscales definen los tipos de documentos fiscales reconocidos por el sistema.
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button id="btnGuardar" class="btn btn-success">Guardar</button>
                            <button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>

            <script>
            $(document).ready(function(){
                // Configuración de DataTable
                var tabla = $('#tablaComprobantesFiscales').DataTable({
                    dom: '<"row"<"col-md-6"l><"col-md-6"fB>>rt<"row"<"col-md-6"i><"col-md-6"p>>',
                    buttons: [
                        {
                            extend: 'excelHtml5',
                            text: '<i class="fas fa-file-excel"></i> Excel',
                            titleAttr: 'Exportar a Excel',
                            className: 'btn btn-success btn-sm me-2',
                            exportOptions: { columns: ':visible' }
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fas fa-file-pdf"></i> PDF',
                            titleAttr: 'Exportar a PDF',
                            className: 'btn btn-danger btn-sm',
                            orientation: 'portrait',
                            pageSize: 'A4',
                            exportOptions: { columns: ':visible' }
                        }
                    ],
                    ajax: {
                        url: 'comprobantes_fiscales_ajax.php',
                        type: 'GET',
                        data: {accion: 'listar'},
                        dataSrc: ''
                    },
                    language: {
                        "search": "Buscar:",
                        "searchPlaceholder": "Buscar comprobantes...",
                        "lengthMenu": "Mostrar _MENU_ registros por página",
                        "zeroRecords": "No se encontraron comprobantes",
                        "info": "Mostrando _START_ a _END_ de _TOTAL_ comprobantes",
                        "infoEmpty": "Mostrando 0 a 0 de 0 comprobantes",
                        "infoFiltered": "(filtrado de _MAX_ comprobantes totales)",
                        "paginate": {
                            "first": "Primero",
                            "last": "Último",
                            "next": "Siguiente",
                            "previous": "Anterior"
                        }
                    },
                    columns: [
                        { data: 'comprobante_fiscal_id' },
                        { 
                            data: 'codigo',
                            render: function(data) {
                                return data.toString().padStart(3, '0');
                            }
                        },
                        { data: 'comprobante_fiscal' },
                        {
                            data: null,
                            orderable: false,
                            searchable: false,
                            className: "text-center",
                            render: function(data){
                                var estadoTexto = data.estado_registro_id == 1 ? 
                                    '<span class="badge bg-success">Activo</span>' : 
                                    '<span class="badge bg-secondary">Inactivo</span>';
                                
                                var botonEstado = 
                                    `<div class="form-check form-switch d-inline-block">
                                        <input class="form-check-input toggle-estado"
                                            type="checkbox" 
                                            data-fiscal-id="${data.comprobante_fiscal_id}" 
                                            ${data.estado_registro_id == 1 ? 'checked' : ''}>
                                    </div>`;
                                
                                return `<div class="d-flex flex-column align-items-center">                                            
                                            ${botonEstado}
                                        </div>`;
                            }
                        },
                        {
                            data: null,
                            orderable: false,
                            searchable: false,
                            className: "text-center",
                            render: function(data){
                                var botonEditar = data.estado_registro_id == 1 ? 
                                    `<button class="btn btn-sm btn-primary btnEditar" title="Editar">
                                        <i class="fa fa-edit"></i>
                                     </button>` : 
                                    `<button class="btn btn-sm btn-secondary" title="Editar no disponible" disabled>
                                        <i class="fa fa-edit"></i>
                                     </button>`;
                                
                                var botonEliminar = data.estado_registro_id == 1 ? 
                                    `<button class="btn btn-sm btn-danger btnEliminar" title="Eliminar">
                                        <i class="fa fa-trash"></i>
                                     </button>` : 
                                    `<button class="btn btn-sm btn-secondary" title="Eliminar no disponible" disabled>
                                        <i class="fa fa-trash"></i>
                                     </button>`;
                                
                                return `<div class="d-flex align-items-center justify-content-center gap-2">${botonEditar} ${botonEliminar}</div>`;
                            }
                        }
                    ],
                    createdRow: function(row, data, dataIndex) {
                        // Cambiar color de fondo según el estado
                        if (data.estado_registro_id != 1) {
                            $(row).addClass('table-secondary');
                            $(row).find('td').css('color', '#6c757d');
                        }
                    }
                });

                // Manejar el cambio de estado con el interruptor
                $(document).on('change', '.toggle-estado', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    var fiscalId = $(this).data('fiscal-id');
                    var isChecked = $(this).is(':checked');
                    var nuevoEstado = isChecked ? 1 : 0;
                    var accionTexto = nuevoEstado == 1 ? 'activar' : 'desactivar';
                   
                    Swal.fire({
                        title: `¿${nuevoEstado == 1 ? 'Activar' : 'Desactivar'} comprobante?`,
                        text: `Está a punto de ${accionTexto} este comprobante fiscal`,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: `Sí, ${accionTexto}`,
                        cancelButtonText: 'Cancelar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.get('comprobantes_fiscales_ajax.php', {
                                accion: 'cambiar_estado', 
                                comprobante_fiscal_id: fiscalId,
                                nuevo_estado: nuevoEstado
                            }, function(res){
                                if(res.resultado){
                                    // 1. En el cambio de estado
                                    if(res.resultado){
                                        // Guardar página actual
                                        var currentPage = tabla.page();
                                        tabla.ajax.reload(function(){
                                            // Restaurar página después de recargar
                                            tabla.page(currentPage).draw('page');
                                        }, false);
                                        
                                    }
                                } else {
                                    // Revertir el cambio visual si hay error
                                    $(this).prop('checked', !isChecked);
                                    Swal.fire({
                                        icon: "error",
                                        title: "Error",
                                        text: res.error || `Error al ${accionTexto} el comprobante`
                                    });
                                }
                            }, 'json');
                        } else {
                            // Revertir visualmente si cancela
                            $(this).prop('checked', !isChecked);
                        }
                    });
                });

                $('#btnNuevo').click(function(){
                    $('#formComprobanteFiscal')[0].reset();
                    $('#comprobante_fiscal_id').val('');
                    $('#modalLabel').text('Nuevo Comprobante Fiscal');
                    $('#estado_registro_id').val('1');
                    var modal = new bootstrap.Modal(document.getElementById('modalComprobanteFiscal'));
                    modal.show();
                });

                $('#tablaComprobantesFiscales tbody').on('click', '.btnEditar', function(){
                    var data = tabla.row($(this).parents('tr')).data();
                    // Solo permitir editar si está activo
                    if (data.estado_registro_id != 1) {
                        Swal.fire({
                            icon: "warning",
                            title: "Comprobante inactivo",
                            text: "No se puede editar un comprobante inactivo. Active el comprobante primero.",
                            showConfirmButton: false,
                            timer: 2000
                        });
                        return false;
                    }
                    
                    $.get('comprobantes_fiscales_ajax.php', {
                        accion: 'obtener', 
                        comprobante_fiscal_id: data.comprobante_fiscal_id
                    }, function(res){
                        if(res){
                            $('#comprobante_fiscal_id').val(res.comprobante_fiscal_id);
                            $('#codigo').val(res.codigo);
                            $('#comprobante_fiscal').val(res.comprobante_fiscal);
                            $('#estado_registro_id').val(res.estado_registro_id);
                            
                            $('#modalLabel').text('Editar Comprobante Fiscal');
                            var modal = new bootstrap.Modal(document.getElementById('modalComprobanteFiscal'));
                            modal.show();
                        } else {
                            alert('Error al obtener datos');
                        }
                    }, 'json');
                });

                // Eliminar comprobante fiscal
                $('#tablaComprobantesFiscales tbody').on('click', '.btnEliminar', function(){
                    var data = tabla.row($(this).parents('tr')).data();
                    
                    Swal.fire({
                        title: '¿Eliminar comprobante fiscal?',
                        text: "Esta acción no se puede deshacer",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sí, eliminar',
                        cancelButtonText: 'Cancelar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.get('comprobantes_fiscales_ajax.php', {
                                accion: 'eliminar', 
                                comprobante_fiscal_id: data.comprobante_fiscal_id
                            }, function(res){
                                if(res.resultado){
                                    // 2. En la eliminación
                                    if(res.resultado){
                                        // Guardar página actual
                                        var currentPage = tabla.page();
                                        tabla.ajax.reload(function(){
                                            // Restaurar página después de recargar
                                            tabla.page(currentPage).draw('page');
                                        }, false);
                                        Swal.fire({
                                            icon: "success",
                                            title: "¡Éxito!",
                                            text: "Comprobante fiscal eliminado correctamente",
                                            showConfirmButton: false,
                                            timer: 1500
                                        });
                                    }

                                    Swal.fire({
                                        icon: "success",
                                        title: "¡Éxito!",
                                        text: "Comprobante fiscal eliminado correctamente",
                                        showConfirmButton: false,
                                        timer: 1500
                                    });
                                } else {
                                    Swal.fire({
                                        icon: "error",
                                        title: "Error",
                                        text: res.error || "Error al eliminar el comprobante fiscal"
                                    });
                                }
                            }, 'json');
                        }
                    });
                });

                $('#btnGuardar').click(function(){
                    var form = document.getElementById('formComprobanteFiscal');
                    
                    if (!form.checkValidity()) {
                        form.classList.add('was-validated');
                        return false;
                    }
                    
                    var id = $('#comprobante_fiscal_id').val();
                    var accion = id ? 'editar' : 'agregar';
                    var formData = {
                        accion: accion,
                        comprobante_fiscal_id: id,
                        codigo: $('#codigo').val(),
                        comprobante_fiscal: $('#comprobante_fiscal').val(),
                        estado_registro_id: $('#estado_registro_id').val()
                    };



                    $.ajax({
                        url: 'comprobantes_fiscales_ajax.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(res) {
                            if(res.resultado) {
                                tabla.ajax.reload(null, false);
                                
                                var modal = bootstrap.Modal.getInstance(document.getElementById('modalComprobanteFiscal'));
                                modal.hide();
                                
                                $('#formComprobanteFiscal')[0].reset();
                                form.classList.remove('was-validated');
                                
                                Swal.fire({
                                    icon: "success",
                                    title: "¡Éxito!",
                                    text: id ? "Comprobante fiscal actualizado correctamente" : "Comprobante fiscal creado correctamente",
                                    showConfirmButton: false,
                                    timer: 1500
                                });
                            } else {
                                Swal.fire({
                                    icon: "error",
                                    title: "Error",
                                    text: res.error || "Error al guardar los datos"
                                });
                            }
                        },
                        error: function() {
                            Swal.fire({
                                icon: "error",
                                title: "Error",
                                text: "Error de conexión con el servidor"
                            });
                        }
                    });
                    if(res.resultado) {
                        // Guardar página actual
                        var currentPage = tabla.page();
                        tabla.ajax.reload(function(){
                            // Restaurar página después de recargar
                            tabla.page(currentPage).draw('page');
                        }, false);
                        
                        var modal = bootstrap.Modal.getInstance(document.getElementById('modalComprobanteFiscal'));
                        modal.hide();
                        
                        $('#formComprobanteFiscal')[0].reset();
                        form.classList.remove('was-validated');
                        
                        Swal.fire({
                            icon: "success",
                            title: "¡Éxito!",
                            text: id ? "Comprobante fiscal actualizado correctamente" : "Comprobante fiscal creado correctamente",
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                });
            });
            </script>
            <style>
            .table-secondary td {
                color: #6c757d !important;
            }
            
            .form-check.form-switch.d-inline-block {
                padding-left: 0;
                margin-bottom: 0;
            }
            
            .form-check-input.toggle-estado {
                width: 3em;
                height: 1.5em;
            }
            
            .badge {
                font-size: 0.75rem;
            }
            
            .form-check.form-switch .form-check-input {
                margin-right: 0.5rem;
            }
            </style>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

            <?php
            require_once ROOT_PATH . '/templates/adminlte/footer1.php';
            ?>
            </body>
            </html>